package com.space.quiz;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Level1 extends AppCompatActivity {


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.universal);
    }
}